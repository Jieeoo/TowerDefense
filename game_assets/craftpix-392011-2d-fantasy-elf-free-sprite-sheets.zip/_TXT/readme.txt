 font - Coraline's Cat
http://www.dafont.com/coralines-cat.font?l[]=10&l[]=1&text=ELF